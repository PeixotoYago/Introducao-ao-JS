/**
 * Created by yago on 05/01/16.
 */
function enviar() {

    var nome = document.getElementById(nome).value
    var dataNS = document.getElementById(dtNasc).value
    var email = document.getElementById(email).value
    var cpf = document.getElementById(cpf).value
    var telefone = document.getElementById(telefone).value
    var senha = document.getElementById(senha).value

    function validarNome() {
        var exNome = new RegExp('^[A-Za-z]$');

        if (nome == exNome) {
            document.getElementById("nome");

        } else {
            alert("O seu nome esta fora dos padrões");
        }
    }

    function validarData() {
        var exData = new RegExp('^([1-9]|0[1-9]|[1,2][0-9]|3[0,1])/([1-9]|1[0,1,2])/\d{4}$', 'ig');

        if (dataNS == exData) {
            document.getElementById("dtNasc");

        } else {
            alert("A sua dada esta fora dos padrões");
        }
    }


    function validarEmail() {
        var exEmail = new RegExp('^[a-zA-Z0-9][a-zA-Z0-9\._-]+@([a-zA-Z0-9\.$');

        if (email == exEmail) {
            document.getElementById("email");

        } else {
            alert("O seu E-mail esta fora dos padrões");
        }

    }

    function validarCpf() {
        var exCpf = new RegExp('^\d{3}\.\d{3}\.\-\d{2}$', 'ig');

        if (cpf == exCpf) {
            document.getElementById("cpf");

        } else {
            alert("O seu CPF esta fora dos padrões");
        }

    }

    function validarTelefone() {
        var exTelefone = new RegExp('^\(?\d{2}\)?[\s-]?\d{4}-?\d{4}$', 'ig');

        if (telefone == exTelefone) {
            document.getElementById("telefone");

        } else {
            alert("O seu Telefone esta fora dos padrões");
        }

    }

    function validarSenha() {
        var exSenha = new RegExp('^[a-zA-Z](?\d{3}\)');

        if (senha == exSenha) {
            document.getElementById("senha");

        } else {
            alert("A sua senha esta fora dos padrões");
        }
    }


    var cooknome = document.querySelector("#nome").value;

    function verificar() {
        var cookie = getCookie("tela2");
        if (cookie != null) {
            window.location = "tela2.html";
        }
    }

    function verificaCook() {

        var cookie = getCookie("tela2");
        if (cookie == null) {
            window.location = "prova2.html";
        }
    }

    function sair() {
        var cookie = getCookie("tela2");
        if (cookie != null) {
            removeCook("tela2");
            window.location = "prova2.html";
        }
    }

    function removeCook(name) {
        var data = new Date(2000, 01, 1, 12, 00, 00);
        var expires = "expires=" + data.toUTCString();
        document.cookie = name + "= ;" + expires;

    }

}